# Deathclaw Creature — experimental territorial brawler v3

Local Cyberpunk 2077 mod. Requires CET and Codeware. The existing Wind Farm statue
is independent and remains available.

Restart the game through MO2 Play, load a save, and open CET with backtick.
Spawn a fresh creature to get the new health record. The panel must say
**Territorial brawler v3**. Script files are installed in both the game and MO2 overwrite. In
**Deathclaw Creature - experimental**, click **Visit creature area**, then
**Spawn creature**. Close the overlay to let the simulation run.

The creature uses a cloned Animals melee-brawler record, a separate NPC entity and a
Deathclaw mesh rebound to Cyberpunk's man_big deformation skeleton. It starts a small
Wind Farm patrol and scans for living NPCs within 50 metres every 0.4 seconds.
V is excluded from automatic hunting, but attacking the creature provokes retaliation.
Territorial targets outside 85 metres of its spawn are released; native combat AI
may retain additional threats. Manual targets bypass the territory leash. The panel also has
**Attack NPC I am looking at**, **Attack V**, **Inspect creature**, and
**Remove creature**. Aim at an NPC with CET closed before opening the panel;
the last aimed target is cached for 15 seconds. Nothing spawns automatically.

The convoy preset multiplies donor maximum health by **20** and outgoing hit
damage by **4**. These are starting balance values, not a promise it can defeat
every convoy. Health is applied through a unique cloned record; other Animals
NPCs are unaffected. The damage hook only scales this creature's attacks and skips
projected/preview hits. Incoming hits queue retaliation on the next 0.2-second
update, with two-second target-switch hysteresis to avoid oscillating between
shooters. The native AI still controls movement, attack choices and animations.
Threats are explicitly injected when engaging. Combat monitoring continues
while a target is alive, with periodic recovery for stalled fights and temporary
exclusion of unreachable targets. Patrol movement uses Run.

The controller acquires NPC targets; it does not force convoy passengers out of
vehicles or add vehicle-smashing animations. Start battle tests with soldiers on foot.

The body follows the large human/Animals animation setup, including standard
unarmed attacks. Tail and fingers are currently rigid and follow hips/hands.
This fitting is approximately 1.96m tall (previous android:1.82m), with the
Deathclaw's bulky torso and claws. Statue-sized scaling, creature-specific animation,
accurate creature hit volumes, and sound replacement are not implemented.

The rig was recovered from the original local New Vegas assets: 78 skeleton
nodes and 66 weighted bones, with 4248 vertices and 6930 triangles. The compiled
Cyberpunk mesh has 181 donor bones. Blender previews use actual large-brawler
walk and attack animations. Compilation and mocked lifecycle tests pass.
The user confirmed v2 attacks and killed V, then fought Voodoo Boys. They reported
slow engagement, unreliable NPC targeting and low durability. V3 retains the tested
v2 mesh/rig/archive and changes the Lua combat controller and stats. Mocked regression
tests pass for targeting, threat injection, damage scoping, retaliation, stalled
target recovery and lifecycle cleanup. V3 native API compatibility, actual health,
responsiveness and battle balance still require an in-game test.

The creature does not persist in saves. It is removed when V moves more than
250m away. Use the panel to spawn again after a reload. It uses a unique record;
it does not replace every android or modify global faction relationships.

Diagnostics are written to the DeathclawCreature CET mod directory. Under MO2,
these normally appear in overwrite. `inspection.json` records NPC presence,
body presence, position, measured max health, target, threat injection count,
incoming/outgoing hit counts and last pre/post multiplier damage. Hit values are
measured before later native processing, not a promise of final health lost.
Diagnostics do not prove visible appearance. Hook errors appear as a warning.

Source tools are in the parent project's tools directory:
extract_creature_rig.py, build_creature_blender.py, build_creature_resources.py,
preview_creature_animation.py, test_creature_lifecycle.py, package_creature.py.
Keep Bethesda assets and this prototype local.
