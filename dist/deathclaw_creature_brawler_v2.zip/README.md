# Deathclaw Creature — experimental large brawler v2

Local Cyberpunk 2077 mod. Requires CET and Codeware. The existing Wind Farm statue
is independent and remains available.

Restart the game through MO2 Play, load a save, and open CET with backtick. In
**Deathclaw Creature - experimental**, click **Visit creature area**, then
**Spawn creature**. Close the overlay to let the simulation run.

The creature uses a cloned Animals melee-brawler record, a separate NPC entity and a
Deathclaw mesh rebound to Cyberpunk's man_big deformation skeleton. It starts a small
Wind Farm patrol and looks for living NPCs within 22 metres. The panel also has
**Attack NPC I am looking at**, **Attack V**, **Inspect creature**, and
**Remove creature**. Nothing spawns automatically on game startup.

The body follows the large human/Animals animation setup, including standard
unarmed attacks. Tail and fingers are currently rigid and follow hips/hands.
This fitting is approximately 1.96m tall (previous android:1.82m), with the
Deathclaw's bulky torso and claws. Statue-sized scaling, creature-specific animation,
accurate creature hit volumes, and sound replacement are not implemented.

The rig was recovered from the original local New Vegas assets: 78 skeleton
nodes and 66 weighted bones, with 4248 vertices and 6930 triangles. The compiled
Cyberpunk mesh has 181 donor bones. Blender previews use actual large-brawler
walk and attack animations. Compilation and mocked lifecycle tests pass.
The user verified spawning, patrol and damage/death for android v1, but reported
blocking without attacks and a limp. V2 replaces both the donor AI record and the
whole NPC entity/rig/animation setup to address that. Its in-game attacks, locomotion,
damage balance, ragdoll and reload behaviour still need testing.

The creature does not persist in saves. It is removed when V moves more than
250m away. Use the panel to spawn again after a reload. It uses a unique record;
it does not replace every android or modify global faction relationships.

Diagnostics are written to the DeathclawCreature CET mod directory. Under MO2,
these normally appear in overwrite. `inspection.json` records NPC presence,
body component presence and position; these do not prove visible appearance or
combat damage.

Source tools are in the parent project's tools directory:
extract_creature_rig.py, build_creature_blender.py, build_creature_resources.py,
preview_creature_animation.py, test_creature_lifecycle.py, package_creature.py.
Keep Bethesda assets and this prototype local.
