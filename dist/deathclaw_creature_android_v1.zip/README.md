# Deathclaw Creature — experimental android prototype

Local Cyberpunk 2077 mod. Requires CET and Codeware. The existing Wind Farm statue
is independent and remains available.

Restart the game through MO2 Play, load a save, and open CET with backtick. In
**Deathclaw Creature - experimental**, click **Visit creature area**, then
**Spawn creature**. Close the overlay to let the simulation run.

The creature uses a cloned boxing-android record, a separate NPC entity and a
Deathclaw mesh rebound to Cyberpunk's deformation skeleton. It starts a small
Wind Farm patrol and looks for living NPCs within 22 metres. The panel also has
**Attack NPC I am looking at**, **Attack V**, **Inspect creature**, and
**Remove creature**. Nothing spawns automatically on game startup.

The body follows android animation. Tail and fingers are currently rigid and
follow hips/hands. The first fitting is about human height (1.8m), with the
Deathclaw's bulky torso and claws. Giant scaling, creature-specific animation,
accurate creature hit volumes, and sound replacement are not implemented.

The rig was recovered from the original local New Vegas assets: 78 skeleton
nodes and 66 weighted bones, with 4248 vertices and 6930 triangles. The compiled
Cyberpunk mesh has 181 donor bones. A Blender preview uses the actual android
walk animation. Compilation and mocked lifecycle tests pass, but in-game mesh,
patrol, combat, damage, ragdoll and reload behaviour remain unverified.

The creature does not persist in saves. It is removed when V moves more than
250m away. Use the panel to spawn again after a reload. It uses a unique record;
it does not replace every android or modify global faction relationships.

Diagnostics are written to the DeathclawCreature CET mod directory. Under MO2,
these normally appear in overwrite. `inspection.json` records NPC presence,
body component presence and position; these do not prove visible appearance or
combat damage.

Source tools are in the parent project's tools directory:
extract_creature_rig.py, build_creature_blender.py, build_creature_resources.py,
preview_creature_animation.py, test_creature_lifecycle.py, package_creature.py.
Keep Bethesda assets and this prototype local.
