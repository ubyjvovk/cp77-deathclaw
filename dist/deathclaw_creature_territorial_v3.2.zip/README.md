# Deathclaw Creature — experimental territorial brawler v3.2

Local Cyberpunk 2077 mod. Requires CET and Codeware. The existing Wind Farm statue
is independent and remains available.

Restart the game through MO2 Play, load a save, and open CET with backtick.
Spawn a fresh creature to get the new health record. The panel must say
**Territorial brawler v3.2**. Script files are installed in both the game and MO2 overwrite. In
**Deathclaw Creature - experimental**, click **Visit creature area**, then
**Spawn creature**. Close the overlay to let the simulation run.

The creature uses a cloned Animals melee-brawler record, a separate NPC entity and a
Deathclaw mesh rebound to Cyberpunk's man_big deformation skeleton. It starts a small
Wind Farm patrol and scans for living NPCs within 120 metres every 0.4 seconds.
V is excluded from automatic hunting, but attacking the creature provokes retaliation.
Territorial targets outside 300 metres of its spawn are released; native combat AI
may retain additional threats. Manual targets bypass the territory leash. The panel also has
**Attack NPC I am looking at**, **Attack V**, **Inspect creature**, and
**Remove creature**. Aim at an NPC with CET closed before opening the panel;
the last aimed target is cached for 15 seconds. Nothing spawns automatically.

The convoy preset multiplies donor maximum health by **20** and outgoing hit
damage by **4**. These are starting balance values, not a promise it can defeat
every convoy. Health is applied through a unique cloned record; other Animals
NPCs are unaffected. The damage hook only scales this creature's attacks and skips
projected/preview hits. Incoming hits queue retaliation on the next 0.2-second
update, with two-second target-switch hysteresis to avoid oscillating between
shooters. The native AI still controls movement, attack choices and animations.
Threats are injected once per target change and made persistent on the creature.
The opponent receives its own threat and combat reaction. Combat is never repeatedly
restarted, and nearby living targets are not cancelled by a timeout. Only distant
(>12m), stalled automatic pursuits can time out after 30 seconds. Manual targets
remain assigned until death, removal, or cancellation. Patrol movement uses Run.
Native target searches use V's targeting component with an expanded radius, then
filter candidates to the creature's 120m radius; the v3 creature-origin query failed
to acquire targets in the user's test.

The controller acquires NPC targets; it does not force convoy passengers out of
vehicles or add vehicle-smashing animations. Start battle tests with soldiers on foot.

The body follows the large human/Animals animation setup, including standard
unarmed attacks. Tail and fingers are currently rigid and follow hips/hands.
This fitting is approximately 1.96m tall (previous android:1.82m), with the
Deathclaw's bulky torso and claws. Statue-sized scaling, creature-specific animation,
accurate creature hit volumes, and sound replacement are not implemented.

The rig was recovered from the original local New Vegas assets: 78 skeleton
nodes and 66 weighted bones, with 4248 vertices and 6930 triangles. The compiled
Cyberpunk mesh has 181 donor bones. Blender previews use actual large-brawler
walk and attack animations. Compilation and mocked lifecycle tests pass.
The user confirmed v2 attacks and killed V, then fought Voodoo Boys. They reported
slow engagement, unreliable NPC targeting and low durability. V3 retains the tested
v2 mesh/rig/archive and changes the Lua combat controller and stats. Mocked regression
tests pass for targeting, threat injection, damage scoping, retaliation, stalled
target recovery and lifecycle cleanup. V3 telemetry confirms 7776 max HP and a hit scaled from 28.48 to 113.93 before
later native processing. The user reported repeated wind-ups, one hit and combat
ending with both actors alive. Diagnostics showed 24 threat injections and the
watchdog cancelling the target. V3.1 removes that interference and adds persistence
and reciprocal combat startup. V3.1 native behavior still needs an in-game test.

The creature does not persist in saves. It is removed when V moves more than
650m away. Use the panel to spawn again after a reload. It uses a unique record;
it does not replace every android or modify global faction relationships.

Diagnostics are written to the DeathclawCreature CET mod directory. Under MO2,
these normally appear in overwrite. `inspection.json` records NPC presence,
body presence, position, measured max health, target, threat injection count,
incoming/outgoing hit counts and last pre/post multiplier damage. Hit values are
measured before later native processing, not a promise of final health lost.
Diagnostics do not prove visible appearance. Hook errors appear as a warning.

Source tools are in the parent project's tools directory:
extract_creature_rig.py, build_creature_blender.py, build_creature_resources.py,
preview_creature_animation.py, test_creature_lifecycle.py, package_creature.py.
Keep Bethesda assets and this prototype local.

## V3.2 controls and territory

**Spawn beside V** places a normal creature eight metres ahead of V, grounded with
a raycast. Use clear outdoor ground. **Spawn Mother beside V (2x)** uses the same
spawn location and an experimental 2x visualScale on the body mesh. It does not
double the native skeleton, hitboxes, melee reach or navigation capsule. Actual
animated appearance needs an in-game check. **Restore normal size** reverts it.
Remove the existing creature before spawning another. The original Spawn creature
button still uses the Wind Farm.

Territory is now 200m radius around the chosen spawn point, with six patrol
waypoints reaching about190m. It detects NPCs within120m of itself and pursues
automatic targets up to300m from its spawn. It retains a waypoint until reached
or120seconds elapse, raycasts waypoint ground and uses native navigation. This is
local loaded-world AI, not an offscreen wildlife simulation.

Detection also considers AMM's spawnedNPCs registry, even when native targeting
misses those actors. When explicitly commanded to attack an NPC with an
AIFollowerRole, it clears that actor's follower role and companion cache before
engaging. This changes the selected NPC's companion behavior; respawn it or use
AMM to restore companionship afterward. AMM invulnerability settings are untouched.
Being spawned alone does not identify the cause: friendly/follower setup and
targeting eligibility are possible causes. V3.1 decisively attacked V per user
test, but spawned-NPC combat remained unreliable. V3.2 needs an engine test.
